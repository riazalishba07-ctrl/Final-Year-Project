import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AlertBanner = ({ alert }) => {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();
  
  if (!isVisible || !alert) return null;
  
  const handleViewDetails = () => {
    navigate('/live-detection');
  };
  
  return (
    <div className="bg-danger-600">
      <div className="max-w-7xl mx-auto py-3 px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between flex-wrap">
          <div className="w-0 flex-1 flex items-center">
            <span className="flex p-2 rounded-lg bg-danger-800">
              <i className="bi bi-exclamation-triangle-fill text-white"></i>
            </span>
            <p className="ml-3 font-medium text-white truncate">
              <span className="md:hidden">
                Fire detected! {alert.confidence}% confidence.
              </span>
              <span className="hidden md:inline">
                Fire detected at {alert.location?.name || 'Unknown location'} with {alert.confidence}% confidence.
              </span>
            </p>
          </div>
          <div className="order-3 mt-2 flex-shrink-0 w-full sm:order-2 sm:mt-0 sm:w-auto">
            <button
              onClick={handleViewDetails}
              className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-danger-600 bg-white hover:bg-danger-50"
            >
              View details
            </button>
          </div>
          <div className="order-2 flex-shrink-0 sm:order-3 sm:ml-3">
            <button
              type="button"
              onClick={() => setIsVisible(false)}
              className="-mr-1 flex p-2 rounded-md hover:bg-danger-500 focus:outline-none focus:ring-2 focus:ring-white sm:-mr-2"
            >
              <span className="sr-only">Dismiss</span>
              <i className="bi bi-x-lg text-white"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AlertBanner;
